package com.example.newsapp.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.newsapp.model.NewsArticle
import com.example.newsapp.network.RetrofitClient
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch

class NewsViewModel : ViewModel() {
    private val _newsList = MutableStateFlow<List<NewsArticle>>(emptyList())
    val newsList: StateFlow<List<NewsArticle>> get() = _newsList

    private val _isLoading = MutableStateFlow(false)
    val isLoading: StateFlow<Boolean> get() = _isLoading

    private val _errorMessage = MutableStateFlow<String?>(null)
    val errorMessage: StateFlow<String?> get() = _errorMessage

    init {
        fetchNews()
    }

    private fun fetchNews() {
        viewModelScope.launch {
            _isLoading.value = true
            _errorMessage.value = null  // Reset error message

            try {
                val apiKey = "0c40b65ff9ea4161977a9b72f20a12ea"
                val response = RetrofitClient.apiService.getTopHeadlines(apiKey)
                println("DEBUG: API Response - ${response.articles}")

                if (response.articles.isNullOrEmpty()) {
                    _errorMessage.value = "Tidak ada berita terbaru."
                } else {
                    _newsList.value = response.articles.mapNotNull {
                        if (it.title != null && it.publishedAt != null && it.url != null) {
                            NewsArticle(
                                title = it.title,
                                description = it.description ?: "",
                                url = it.url,
                                urlToImage = it.urlToImage ?: "",
                                publishedAt = it.publishedAt
                            )
                        } else {
                            null  // Skip jika ada elemen penting yang null
                        }
                    }
                }
            } catch (e: Exception) {
                _errorMessage.value = "Gagal memuat berita: ${e.message}"
                println("DEBUG: API Error - ${e.message}")

            } finally {
                _isLoading.value = false
            }
        }
    }
}
